<template>

</template>

<script>
  const baseUrl = ''
  const proUrl = 'http://bigdata13:8082'
    export default {
        baseUrl,
        proUrl
    }
</script>

<style scoped>

</style>
