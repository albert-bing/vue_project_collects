import Vue from 'vue'
import Router from 'vue-router'
import AuroraLargeScreen from '@/components/AuroraLargeScreen'
import WTScreen from '@/components/WTScreen'
import Test from '@/components/Test'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'WTScreen',
      component: WTScreen
    },
    {
      path: '/auroraLargeScreen',name: 'AuroraLargeScreen',component: AuroraLargeScreen
    },
    {
    path:'/test',name:'Test',component:Test
    }
  ]
})
