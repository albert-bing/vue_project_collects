// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

import echarts from 'echarts'
Vue.prototype.$echarts = echarts
import axios from 'axios'

Vue.prototype.$axios = axios
axios.defaults.baseURL = '/api'

// 挂载全局变量
import globalEle from './components/Global'
Vue.prototype.Global = globalEle

Vue.config.productionTip = false

// import "assets/css/app.css"
// import "assets/css/bootstrap.min.css"

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
